import {
  Controller,
  Post,
  Get,
  Body,
  Patch,
  Param,
  Query,
  NotFoundException,
} from '@nestjs/common';
import { RoutineService } from './routine.service';
import { GoalService } from '../Goal/Goal.service';
import { BodyInfoService } from '../body-info/body-info/body-info.service';
import * as fs from 'fs';
import * as path from 'path';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { CompletedExercise, CompletedExerciseDocument } from './completed-exercise.schema';
import effectMap from '../../data/exercise-effects.json'; // ✅ 추가
@Controller('routine')
export class RoutineController {
  constructor(
    private readonly routineService: RoutineService,
    private readonly goalService: GoalService,
    private readonly bodyInfoService: BodyInfoService,
    @InjectModel(CompletedExercise.name)
    private readonly completedModel: Model<CompletedExerciseDocument>,
  ) {}

  @Post()
  async getRoutine(@Body('userId') userId: string) {
    const goal = await this.goalService.findByUserId(userId);
    const body = await this.bodyInfoService.findByUserId(userId);

    if (!goal || !body) {
      throw new NotFoundException('goal 또는 body 정보가 없습니다.');
    }

    return this.routineService.generateRoutine({
      userId,
      goal: goal.goal,
      difficulty: goal.difficulty,
      frequency: goal.frequency,
       weight: body.weight,
    });
  }

  @Patch(':userId/:day')
  async updateDayRoutine(
    @Param('userId') userId: string,
    @Param('day') day: string,
    @Body('exercises') exercises: any[],
  ) {
    return this.routineService.updateDayRoutine(userId, day, exercises);
  }

  @Get('/exercise-info')
  getExerciseInfo(@Query('name') name: string, @Query('part') part?: string) {
    const dbPath = path.join(__dirname, '../../data/routines.json');
    if (!fs.existsSync(dbPath)) {
      throw new NotFoundException('routines.json 파일이 없습니다.');
    }

    const db = JSON.parse(fs.readFileSync(dbPath, 'utf-8'));

    const normalize = (text: string) =>
      decodeURIComponent(text)
        .replace(/\s+/g, ' ')
        .replace(/[^\w\s]/gi, '')
        .trim()
        .toLowerCase();

    const targetName = normalize(name);
    const targetPart = part ? normalize(part) : null;

    for (const goalKey in db) {
      const parts = db[goalKey];
      for (const partKey in parts) {
        for (const levelKey in parts[partKey]) {
          for (const ex of parts[partKey][levelKey]) {
            const exName = normalize(ex.name);
            const exPart = normalize(partKey);

            const nameMatches = exName === targetName;
            const partMatches = !targetPart || exPart === targetPart;

            if (nameMatches && partMatches) {
              return {
                ...ex,
                part: partKey,
                description: ex.description || `${partKey} 부위를 자극하는 대표적인 운동입니다.`,
                videoUrl: ex.videoUrl || '',
              };
            }
          }
        }
      }
    }

    throw new NotFoundException(`${name} 운동을 찾을 수 없습니다.`);
  }

  @Post('/complete')
async completeExercise(@Body() body: { userId: string; name: string; date: string }) {
  const logPath = path.join(__dirname, '../../data/completed.json');
  const log = fs.existsSync(logPath) ? JSON.parse(fs.readFileSync(logPath, 'utf-8')) : [];

  log.push(body);
  fs.writeFileSync(logPath, JSON.stringify(log, null, 2), 'utf-8');

  // ✅ 운동 효과 반영
  const effect = effectMap[body.name];
  if (effect) {
    const statsPath = path.join(__dirname, '../../data/statistics.json');
    const stats = fs.existsSync(statsPath)
      ? JSON.parse(fs.readFileSync(statsPath, 'utf-8'))
      : {};

    if (!stats[body.userId]) {
      stats[body.userId] = { weightChange: 0, muscleChange: 0 };
    }

    stats[body.userId].weightChange += effect.weightChange;
    stats[body.userId].muscleChange += effect.muscleChange;

    fs.writeFileSync(statsPath, JSON.stringify(stats, null, 2), 'utf-8');
  }

  return { success: true };
}

  @Get('/completed/:userId')
  async getCompleted(@Param('userId') userId: string) {
    return this.completedModel.find({ userId }).exec();
  }
// ✅ 운동 효과 통계 반환
  @Get('/statistics/:userId')
  getStatistics(@Param('userId') userId: string) {
    const statsPath = path.join(__dirname, '../../data/statistics.json');

    if (!fs.existsSync(statsPath)) {
      return { weightChange: 0, muscleChange: 0 };
    }

    const stats = JSON.parse(fs.readFileSync(statsPath, 'utf-8'));
    const userStats = stats[userId] || { weightChange: 0, muscleChange: 0 };

    return userStats;
  }
  @Get('/exercise-list/:goal/:part/:level')
  getExerciseList(
    @Param('goal') goal: string,
    @Param('part') part: string,
    @Param('level') level: string,
  ) {
    const dbPath = path.join(__dirname, '../../data/routines.json');
    if (!fs.existsSync(dbPath)) {
      throw new NotFoundException('routines.json 파일이 없습니다.');
    }

    const db = JSON.parse(fs.readFileSync(dbPath, 'utf-8'));
    const goalMap = {
      Normal: '근육 증가',
      FatLoss: '체지방 감량',
      Endurance: '체력 강화',
    };
    const realGoal = goalMap[goal] || goal;
    const exercises = db[realGoal]?.[part]?.[level] || [];

    return exercises.map((ex) => ({
      ...ex,
      part,
    }));
  }

  @Get(':userId')
  async getAllRoutines(@Param('userId') userId: string) {
    return this.routineService.getAllRoutines(userId);
  }
}
