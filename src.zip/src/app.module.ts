import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { RoutineService } from './routine.service';
import { RoutineController } from './routine.controller';
import { Routine, RoutineSchema } from './routine.schema';
import { CompletedExercise, CompletedExerciseSchema } from './completed-exercise.schema'; // ✅ 추가

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Routine.name, schema: RoutineSchema },
      { name: CompletedExercise.name, schema: CompletedExerciseSchema }, // ✅ 추가
    ]),
  ],
  controllers: [RoutineController],
  providers: [RoutineService],
})
export class RoutineModule {}
